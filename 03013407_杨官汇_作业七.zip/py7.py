import unittest
import seuif97

class Region2Test (unittest.TestCase):

    def setUp(self):
         self.T0=273.15

         # Table 15 Page 17 : p,T(K),v(m^3/kg),h(kJ/kg),u(kJ/kg),s(kJ/(kg.k)),Cp(kJ/(kg.k)),w(m/s)
         self.tab15=[  [0.0035,300,0.394913866e2,0.254991145e4,0.241169160e4,0.852238967e1,0.191300162e1,0.427920172e3],
                   [0.0035,700,0.923015898e2,0.333568375e4,0.301262819e4,0.101749996e2,0.208141274e1,0.644289068e3],
                   [30,700,0.00542946619,0.263149474e4,0.246861076e4,0.517540298e1,0.103505092e2,0.480386523e3]]
#以上数据为把IF97-Rev中第17页table15的所有数据按后面压力P温度T等等顺序依次输入进去
    def test_vol(self):#测试一定压强一定温度下的比热容
         places = 7#精确到小数点后7位数
         for item in  self.tab15:
             self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.T0,3),item[2],places)

    def test_enthalpy(self):#测试一定压强一定温度下的焓
         places = 5#精确到小数点后5位数
         for item in  self.tab15:
             self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.T0,4),item[3],places)
             
    def test_energy(self):#测试一定压强一定温度下的内能
         places = 5#精确到小数点后5位数
         for item in  self.tab15:
             self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.T0,7),item[4],places)
             
    def test_entropy(self):#测试一定压强一定温度下的熵
         places = 6#精确到小数点后6位数
         for item in  self.tab15:
             self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.T0,5),item[5],places)
             
    def test_isobaric(self):#测试一定压强一定温度下的定压比热容
         places = 7#精确到小数点后7位数
         for item in  self.tab15:
             self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.T0,8),item[6],places)
             
    def test_Speedofsound(self):#测试一定压强一定温度下的声速
         places = 6#精确到小数点后6位数
         for item in  self.tab15:
             self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.T0,10),item[7],places)

class Region2BackwardTest (unittest.TestCase):

    def setUp(self):
         self.T0=273.15
         
         self.tab24=[[0.001,3000,0.534433241E3],
                     [3,3000,0.575373370E3],
                     [3,4000,0.101077577E4],
                     [5,3500,0.801299102E3],
                     [5,4000,0.101531583E4],
                     [25,3500,0.875279054E3],
                     [40,2700,0.743056411E3],
                     [60,2700,0.791137067E3],
                     [60,3200,0.882756860E3]
                     ]#p,h,T
         self.tab29=[[0.1,7.5,0.399517097E3],
                     [0.1,8,0.514127081E3],
                     [2.5,8,0.103984917E4],
                     [8,6,0.600484040E3],
                     [8,7.5,0.106495556E4],
                     [90,6,0.103801126E4],
                     [20,5.75,0.697992849E3],
                     [80,5.25,0.854011484E3],
                     [80,5.75,0.949017998E3]
                     ]#p,h,T
    def test_hTemperature(self):#验证由p,h求t的正确性
          places = 1
          for item in  self.tab24:
              self.assertAlmostEqual(seuif97.ph(item[0], item[1],1),item[2]-self.T0,places)


    def test_h_TemperaturePH(self):#一致性测试
          places = 8
          for item in  self.tab24:
              p=item[0]
              t=item[2]-self.T0
              h=seuif97.pt2h(p,t)
              self.assertAlmostEqual(seuif97.ph(p,h,1),t,places)
              
    def test_sTemperature(self):#验证由p,s求t的正确性
          places = 1
          for item in  self.tab29:
              self.assertAlmostEqual(seuif97.ps(item[0], item[1],1),item[2]-self.T0,places)
              
    def test_s_Temperature(self):#一致性测试
          places = 8
          for item in  self.tab29:
              p=item[0]
              t=item[2]-self.T0
              s=seuif97.pt2s(p,t)
              self.assertAlmostEqual(seuif97.ps2t(p, s),t,places) 
              
def suite_use_make_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Region2Test))
    suite.addTest(unittest.makeSuite(Region2BackwardTest))
    return suite

if __name__ == '__main__':
    unittest.main(defaultTest='suite_use_make_suite') 